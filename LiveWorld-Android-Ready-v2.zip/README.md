# Live World — Android

نسخة Android جاهزة للبناء السحابي.

## البناء عبر Nova APK Builder
1. ارفع هذا الملف ZIP كما هو.
2. اختر Generate new signing key لأول مرة.
3. اضغط Create APK.
4. إذا ظهر خطأ قبل بدء البناء مثل "فشل إنشاء الإصدار: غير موجود" فهذا خطأ في جلسة GitHub/Release وليس في المشروع؛ أعد الاتصال بـ GitHub ثم أعد المحاولة.

## مواصفات المشروع
- applicationId: com.liveworld.app
- versionCode: 1
- versionName: 1.0.0
- compileSdk: 35
- minSdk: 23
- targetSdk: 35
- AGP: 8.7.3
- Gradle: 8.10.2
